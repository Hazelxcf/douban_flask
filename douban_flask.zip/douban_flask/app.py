from flask import Flask, render_template
import sqlite3
from Spider import spider

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/index')
def home():
    return index()


# 路由解析
@app.route('/movie')
def movie():
    datalist = []
    con = sqlite3.connect('movie.db')
    cur = con.cursor()
    sql = "select * from movie250"
    # print(sql)
    data = cur.execute(sql)
    for item in data:
        datalist.append(item)
        # print(item)
    cur.close()
    con.close()
    return render_template("movie.html", movies=datalist)
    # 模板渲染


@app.route('/download')
def score():
    spider.mainOne()
    # return '下载成功'
    return render_template("download.html")


@app.route('/aboutUs')
def team():
    return render_template("aboutUs.html")


if __name__ == '__main__':
    app.run(debug=True)
